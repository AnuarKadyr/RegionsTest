import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.response.Response;
import org.junit.Assert;
import org.junit.jupiter.api.*;

import java.util.ArrayList;

import static io.restassured.RestAssured.given;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

@DisplayName("Поиск регионов")
public class SearchRegions {
  @Test
  @Order(1)
  @DisplayName("Проверка поиска города. Значение total и items.")
  void SearchRegionsByNameMoscow() {
    Response response = given()
      .queryParam("q", "Москва")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    ArrayList items = response.path("items");
    int total = response.path("total");

    Assert.assertEquals(items.size(), total);
  }

  @Test
  @Order(2)
  @DisplayName("Проверка поиска города. Проверка названия города, страны и кода страны.")
  void SearchRegionsByNameMoscow1() {
    Response response = given()
      .queryParam("q", "Москва")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    String city = response.path("items[0].name.");
    String country = response.path("items[0].country.name");
    String countryCode = response.path("items[0].country.code");

    Assert.assertEquals(city, "Москва");
    Assert.assertEquals(country, "Россия");
    Assert.assertEquals(countryCode, "ru");
  }

  @Test
  @Order(3)
  @DisplayName("Проверка поиска города. Значение total и items.")
  void SearchRegionsByNameOrsk() {
    Response response = given()
      .queryParam("q", "Орск")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    ArrayList items = response.path("items");
    int total = response.path("total");

    Assert.assertEquals(items.size(), total);
  }

  @Test
  @Order(4)
  @DisplayName("Проверка поиска города. Найден только 1 город")
  void SearchRegionsByNameOrsk1() {
    Response response = given()
      .queryParam("q", "Орск")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    ArrayList items = response.path("items");

    Assert.assertEquals(items.size(), 1);
  }

  @Test
  @Order(5)
  @DisplayName("Проверка значений для каждого города")
  void SearchRegionsByNameOrsk2() {
    Response response = given()
      .queryParam("q", "Орск")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();


    String city = response.path("items[0].name.");
    String country = response.path("items[0].country.name");
    String countryCode = response.path("items[0].country.code");

    Assert.assertEquals(city, "Орск");
    Assert.assertEquals(country, "Россия");
    Assert.assertEquals(countryCode, "ru");
  }

  @Test
  @Order(6)
  @DisplayName("Проверка значений для каждого города")
  void SearchRegionsByNameOrsk3() {
    Response response = given()
      .queryParam("q", "Орск")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    String city = response.path("items[1].name.");
    String country = response.path("items[1].country.name");
    String countryCode = response.path("items[1].country.code");

    Assert.assertEquals(city, "Орск");
    Assert.assertEquals(country, "Россия");
    Assert.assertEquals(countryCode, "ru");
  }

  @Test
  @Order(7)
  @DisplayName("Проверка значений для каждого города")
  void SearchRegionsByNameOrsk4() {
    Response response = given()
      .queryParam("q", "Орск")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    String city = response.path("items[2].name.");
    String country = response.path("items[2].country.name");
    String countryCode = response.path("items[2].country.code");

    Assert.assertEquals(city, "Орск");
    Assert.assertEquals(country, "Россия");
    Assert.assertEquals(countryCode, "ru");
  }

  @Test
  @Order(8)
  @DisplayName("Провекра total и items при поиске по country_code")
  void SearchRegionsByCountryCode() {
    Response response = given()
      .queryParam("country_code", "kz")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    ArrayList items = response.path("items");

    int total = response.path("total");

    Assert.assertEquals(items.size(), total);
  }

  @Test
  @Order(9)
  @DisplayName("Успешная проверка")
  void SearchRegionsByCountryCode1() {
    Response response = given()
      .queryParam("country_code", "kz")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    String country = response.path("items[0].country.name");
    String countryCode = response.path("items[0].country.code");

    Assert.assertEquals(country, "Казахстан");
    Assert.assertEquals(countryCode, "kz");
  }

  @Test
  @Order(10)
  @DisplayName("Не успешная проверка")
  void SearchRegionsByCountryCode2() {
    Response response = given()
      .queryParam("country_code", "kz")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    String country = response.path("items[3].country.name");
    String countryCode = response.path("items[3].country.code");

    Assert.assertEquals(country, "Казахстан");
    Assert.assertEquals(countryCode, "kz");
  }

  @Test
  @Order(11)
  @DisplayName("Проверка значений для каждого города c q и country_code")
  void SearchRegionsByNameCountryCode() {
    Response response = given()
      .queryParam("q", "Орск")
      .queryParam("country_code", "ru")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();


    String city = response.path("items[0].name.");
    String country = response.path("items[0].country.name");
    String countryCode = response.path("items[0].country.code");

    Assert.assertEquals(city, "Орск");
    Assert.assertEquals(country, "Россия");
    Assert.assertEquals(countryCode, "ru");
  }

  @Test
  @Order(12)
  @DisplayName("Проверка значений для каждого города c q и country_code")
  void SearchRegionsByNameCountryCode1() {
    Response response = given()
      .queryParam("q", "Орск")
      .queryParam("country_code", "ru")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    String city = response.path("items[1].name.");
    String country = response.path("items[1].country.name");
    String countryCode = response.path("items[1].country.code");

    Assert.assertEquals(city, "Орск");
    Assert.assertEquals(country, "Россия");
    Assert.assertEquals(countryCode, "ru");
  }

  @Test
  @Order(13)
  @DisplayName("Проверка значений для каждого города c q и country_code")
  void SearchRegionsByNameCountryCode2() {
    Response response = given()
      .queryParam("q", "Орск")
      .queryParam("country_code", "ru")
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    String city = response.path("items[2].name.");
    String country = response.path("items[2].country.name");
    String countryCode = response.path("items[2].country.code");

    Assert.assertEquals(city, "Орск");
    Assert.assertEquals(country, "Россия");
    Assert.assertEquals(countryCode, "ru");
  }
}
