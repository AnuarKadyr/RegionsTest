import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.response.Response;
import org.junit.Assert;
import org.junit.jupiter.api.*;

import javax.xml.ws.Response;
import java.util.ArrayList;

import static io.restassured.RestAssured.given;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

@DisplayName("Список регионов")
public class Regions {
  @Test
  @Order(1)
  @DisplayName("Сравнения кол-ва списка в items  и значения total. В items 9, в total 22.")
  void ListRegions() {
    Response response = given()
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    ArrayList items = response.path("items");

    int total = response.path("total");

    Assert.assertEquals(items.size(), total);
  }
}