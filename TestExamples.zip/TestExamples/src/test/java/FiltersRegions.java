import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.response.Response;
import org.junit.Assert;
import org.junit.jupiter.api.*;

import java.util.ArrayList;

import static io.restassured.RestAssured.given;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

@DisplayName("Фильтры регионов")
public class FiltersRegions {
  @Test
  @Order(1)
  @DisplayName("Просмотр c page. Макс значение page = 3 после нет городов. Скорее всего просто нет в базе просто")
  void FiltersRegionsPage() {
    Response response = given()
      .queryParam("page", 2)
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    ArrayList items = response.path("items");

    int total = response.path("total");

    Assert.assertEquals(items.size(), total);
  }

  @Test
  @Order(2)
  @DisplayName("Проверка total и items. При page и page_size")
  void FiltersRegionsPageAndPageSize() {
    Response response = given()
      .queryParam("page", 2)
      .queryParam("page_size", 15)
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    ArrayList items = response.path("items");

    int total = response.path("total");

    Assert.assertEquals(items.size(), total);
  }

  @Test
  @Order(3)
  @DisplayName("В первом запросе 10 items. В 3 при указание page и page_size их 7 items. Page одинаковый = 2")
  void FiltersRegionsPageAndPageSize1() {
    Response response = given()
      .queryParam("page", 2)
      .queryParam("page_size", 15)
      .filter(new AllureRestAssured())
      .log().uri()
      .baseUri("https://regions-test.2gis.com")
      .when()
      .get("/1.0/regions")
      .then()
      .log().body()
      .statusCode(200)
      .extract()
      .response();

    ArrayList items = response.path("items");

    Assert.assertEquals(items.size(), 10);
  }
}
